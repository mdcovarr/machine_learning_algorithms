Michael Covarrubias 
PID#: A12409694
Naveen Ketagoda 
PID#: A10773459

Problem 3
- For this problem we were running short on time so as you may notice our 
code is not as clean as I'd like it to be. In order to get the values determined
for p = 3, 4 and 5 you need to manually change the p value within the program. The same is true for running the kernel perceptron algorithm on the training 
data or test data. You need to manually change the input file to either be 
hw5train.txt or hw5test.txt

Since time was also cut short we were not able to finish 3.3 however int he homework write up we did include the W_t that we calculated when running 
p = 5. this W_t has all the indices of the training data that are included 
within W_t

- In the second submission of our homework we did include the results for problem 3.3 
which as submitted after the deadline for partial credit. I mentioned to professor 
Chaudhuri about submission for Problem 3.3 after the deadline for partial credit, to which she approved if submission was before 5pm today Friday March 10th, 2017.
